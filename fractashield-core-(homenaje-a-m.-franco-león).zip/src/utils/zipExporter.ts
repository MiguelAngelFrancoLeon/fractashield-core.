import JSZip from 'jszip';

// Import raw source files using Vite's ?raw feature
import indexHtmlRaw from '../../index.html?raw';
import packageJsonRaw from '../../package.json?raw';
import tsconfigRaw from '../../tsconfig.json?raw';
import viteConfigRaw from '../../vite.config.ts?raw';
import readmeRaw from '../../README.md?raw';
import deployWorkflowRaw from '../../.github/workflows/deploy.yml?raw';

import mainTsxRaw from '../main.tsx?raw';
import indexCssRaw from '../index.css?raw';
import appTsxRaw from '../App.tsx?raw';
import tetrahedronRaw from '../components/Tetrahedron3D.tsx?raw';
import bruteForceRaw from '../components/BruteForceSimulator.tsx?raw';
import integrityRaw from '../components/IntegritySealCard.tsx?raw';
import francoLeonRaw from '../components/FrancoLeonModal.tsx?raw';
import authorshipRaw from '../components/AuthorshipLicenseModal.tsx?raw';
import cryptoMathRaw from './cryptoMath.ts?raw';
import soundEffectsRaw from './soundEffects.ts?raw';

export async function downloadProjectZip(repoName = 'fractashield-core') {
  const zip = new JSZip();

  // Root files
  zip.file('index.html', indexHtmlRaw);
  zip.file('package.json', packageJsonRaw);
  zip.file('tsconfig.json', tsconfigRaw);
  zip.file('vite.config.ts', viteConfigRaw);
  zip.file('README.md', readmeRaw);
  zip.file('.gitignore', `node_modules\ndist\n.DS_Store\n*.local\n.env\n`);

  // GitHub Actions Workflow for automated Pages deployment
  const githubFolder = zip.folder('.github');
  const workflowsFolder = githubFolder?.folder('workflows');
  workflowsFolder?.file('deploy.yml', deployWorkflowRaw);

  // src folder
  const srcFolder = zip.folder('src');
  srcFolder?.file('main.tsx', mainTsxRaw);
  srcFolder?.file('index.css', indexCssRaw);
  srcFolder?.file('App.tsx', appTsxRaw);

  // components
  const componentsFolder = srcFolder?.folder('components');
  componentsFolder?.file('Tetrahedron3D.tsx', tetrahedronRaw);
  componentsFolder?.file('BruteForceSimulator.tsx', bruteForceRaw);
  componentsFolder?.file('IntegritySealCard.tsx', integrityRaw);
  componentsFolder?.file('FrancoLeonModal.tsx', francoLeonRaw);
  componentsFolder?.file('AuthorshipLicenseModal.tsx', authorshipRaw);

  // utils
  const utilsFolder = srcFolder?.folder('utils');
  utilsFolder?.file('cryptoMath.ts', cryptoMathRaw);
  utilsFolder?.file('soundEffects.ts', soundEffectsRaw);
  utilsFolder?.file('zipExporter.ts', `// Exporter utility included in bundle`);

  // Generate ZIP blob and trigger download
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${repoName}-github-ready.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
